from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import DataCollatorForLanguageModeling
from transformers import Trainer, TrainingArguments
from transformers import pipeline
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader
from torch.optim import AdamW
from transformers import get_scheduler
from torch.nn.parallel import DataParallel
import torch
import matplotlib.pyplot as plt
import time
from tqdm import tqdm
import pandas as pd
import h3
import pickle
import os
import torch
import torch.nn.functional as F

retrained_lm_model_save_dir = '/home/uddeshya.singh/Trained_model/save/'
retrained_lm_model_out_dir = '/home/uddeshya.singh/Trained_model/out/'
model_dir = "/home/uddeshya.singh/Models/pan_india_train_threshold_save_dir"
checkpoints_dir = "/home/uddeshya.singh/Trained_model/"

address_data_path = "/home/uddeshya.singh/DATA/PUNJAB/PUNJAB_with_grid_ids_train.csv"
df = pd.read_csv(address_data_path)

print('starting now ', time.strftime('%X %x %Z'))
address_data_train = load_dataset("csv", data_files=address_data_path, split='train[:100%]')
print('completed now ', time.strftime('%X %x %Z'))

print('starting now ', time.strftime('%X %x %Z'))
address_data_train = address_data_train.map(lambda x: {'grid_id_str': str(x['grid_id'])}, batched=False)
print('completed now ', time.strftime('%X %x %Z'))

print('starting now ', time.strftime('%X %x %Z'))
address_data_train = address_data_train.class_encode_column("grid_id")
print('completed now ', time.strftime('%X %x %Z'))

def get_neighbors(h3_index):
    neighbors_1 = list(h3.k_ring(h3_index, 1))
    neighbors_2 = list(h3.k_ring(h3_index, 2) - set(neighbors_1))
    neighbors_3 = list(h3.k_ring(h3_index, 3) - set(h3.k_ring(h3_index, 2)))
    return neighbors_1, neighbors_2, neighbors_3

neighbors_lookup = {}
label_to_grid_id_str = {}

for idx, row in tqdm(address_data_train.to_pandas().iterrows(), total=address_data_train.num_rows):
    grid_id_str = row['grid_id_str']
    label = row['grid_id']
    neighbors_lookup[grid_id_str] = get_neighbors(grid_id_str)
    label_to_grid_id_str[label] = grid_id_str


with open('/home/uddeshya.singh/Trained_model/pickle/neighbors_lookup.pkl', 'wb') as f:
    pickle.dump(neighbors_lookup, f)
with open('/home/uddeshya.singh/Trained_model/pickle/label_to_grid_id_str.pkl', 'wb') as f:
    pickle.dump(label_to_grid_id_str, f)
    
print(len(neighbors_lookup) , len(label_to_grid_id_str))    
    
# import pickle


# neighbors_lookup_path = '/home/uddeshya.singh/Trained_model/pickle/neighbors_lookup.pkl'
# label_to_grid_id_str_path = '/home/uddeshya.singh/Trained_model/pickle/label_to_grid_id_str.pkl'


# with open(neighbors_lookup_path, 'rb') as f:
#     neighbors_lookup = pickle.load(f)

# with open(label_to_grid_id_str_path, 'rb') as f:
#     label_to_grid_id_str = pickle.load(f)

# print("Sample neighbors lookup:")
# for key in list(neighbors_lookup.keys())[:1]:
#     print(f"{key}: {neighbors_lookup[key]}")

# print("Sample label to grid_id_str mapping:")
# for key in list(label_to_grid_id_str.keys())[:1]:
#     print(f"{key}: {label_to_grid_id_str[key]}")

# print(type(neighbors_lookup) , type(label_to_grid_id_str))    
    

# print("Sample neighbors lookup:")
# for key in list(neighbors_lookup.keys())[:1]:
#     print(f"{key}: {neighbors_lookup[key]}")

def clean_dataset(batch):
    if pd.isnull(batch['cleaned_address']) or batch['cleaned_address'] == '':
        return False
    return True

print('starting now ', time.strftime('%X %x %Z'))
address_data_train = address_data_train.filter(clean_dataset)
print('completed now ', time.strftime('%X %x %Z'))

pretrained_tokenizer = AutoTokenizer.from_pretrained(model_dir)

def tokenize(batch):
    tokenized_batch = pretrained_tokenizer(batch["cleaned_address"], padding=True, truncation=True, max_length=100)
    return tokenized_batch

print('starting now ', time.strftime('%X %x %Z'))
address_data_train = address_data_train.rename_column('grid_id', 'labels')
print('completed now ', time.strftime('%X %x %Z'))

print('starting now ', time.strftime('%X %x %Z'))
print("set_making...........")
train_dataset = address_data_train.map(tokenize, batched=True, batch_size=100000, num_proc=7)

def custom_collate_fn(batch):
    neighbors_1 = [neighbors_lookup[label_to_grid_id_str[item['labels']]][0] for item in batch]
    neighbors_2 = [neighbors_lookup[label_to_grid_id_str[item['labels']]][1] for item in batch]
    neighbors_3 = [neighbors_lookup[label_to_grid_id_str[item['labels']]][2] for item in batch]

    input_ids = pad_sequence([torch.tensor(item['input_ids']) for item in batch], batch_first=True, padding_value=pretrained_tokenizer.pad_token_id)
    attention_mask = pad_sequence([torch.tensor(item['attention_mask']) for item in batch], batch_first=True, padding_value=0)
    labels = torch.tensor([item['labels'] for item in batch])

    return {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'labels': labels,
        'neighbors_1': neighbors_1,
        'neighbors_2': neighbors_2,
        'neighbors_3': neighbors_3
    }

train_dataloader = DataLoader(train_dataset, batch_size=512, collate_fn=custom_collate_fn)

checkpoints_dir = "/home/uddeshya.singh/Trained_model/"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = AutoModelForSequenceClassification.from_pretrained(model_dir, num_labels=len(train_dataset.features['labels'].names))
model.to(device)
model = DataParallel(model)

optimizer = AdamW(model.parameters(), lr=5e-5)
num_training_steps = len(train_dataloader) * 10
lr_scheduler = get_scheduler(
    name="linear", optimizer=optimizer, num_warmup_steps=0, num_training_steps=num_training_steps
)


class NeighborAwareLabelSmoothingLoss(torch.nn.Module):
    def __init__(self, smoothing=0.01, first_order_weight=0.05, second_order_weight=0.03, third_order_weight=0.02):
        super(NeighborAwareLabelSmoothingLoss, self).__init__()
        self.smoothing = smoothing
        self.first_order_weight = first_order_weight
        self.second_order_weight = second_order_weight
        self.third_order_weight = third_order_weight

    def forward(self, output, target, neighbors_1, neighbors_2, neighbors_3):
        num_classes = output.size(-1)
        confidence = 1.0 - self.smoothing
        smoothed_label_dist = torch.full((output.size(0), num_classes), self.smoothing / (num_classes - 1)).to(output.device)
        
        for idx, label in enumerate(target):
            smoothed_label_dist[idx][label] = confidence
            if neighbors_1[idx]:
                weight_1 = self.first_order_weight / len(neighbors_1[idx])
                for neighbor in neighbors_1[idx]:
                    neighbor_idx = int(neighbor, 16) % num_classes  
                    smoothed_label_dist[idx][neighbor_idx] = weight_1
            if neighbors_2[idx]:
                weight_2 = self.second_order_weight / len(neighbors_2[idx])
                for neighbor in neighbors_2[idx]:
                    neighbor_idx = int(neighbor, 16) % num_classes 
                    smoothed_label_dist[idx][neighbor_idx] = weight_2
            if neighbors_3[idx]:
                weight_3 = self.third_order_weight / len(neighbors_3[idx])
                for neighbor in neighbors_3[idx]:
                    neighbor_idx = int(neighbor, 16) % num_classes  
                    smoothed_label_dist[idx][neighbor_idx] = weight_3
        
        log_probs = torch.nn.functional.log_softmax(output, dim=-1)
        loss = (-smoothed_label_dist * log_probs).sum(dim=-1).mean()
        return loss

    
loss_fn = NeighborAwareLabelSmoothingLoss()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

iteration = 0  
losses = []  

print('starting now ', time.strftime('%X %x %Z'))
model.train()

for epoch in range(10):
    total_loss = 0  
    
    for batch in tqdm(train_dataloader):
        batch = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
        outputs = model(input_ids=batch['input_ids'], attention_mask=batch['attention_mask'])
        logits = outputs.logits
        loss = loss_fn(logits, batch['labels'], batch['neighbors_1'], batch['neighbors_2'], batch['neighbors_3'])

        loss.backward()
        optimizer.step()
        lr_scheduler.step()
        optimizer.zero_grad()

        total_loss += loss.item()  

        if iteration % 13000 == 0 and iteration != 0:
            checkpoint_path = os.path.join(checkpoints_dir, f"checkpoint_{iteration}.pt")
            torch.save({
                'iteration': iteration,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': loss
            }, checkpoint_path)
            print(f"Iteration {iteration} - Loss: {loss.item()} - Checkpoint saved at {checkpoint_path}")

        iteration += 1
    
    avg_loss = total_loss / len(train_dataloader) 
    losses.append(avg_loss)
    print(f"Epoch {epoch+1} completed - Average Loss: {avg_loss}")


model.save_pretrained(retrained_lm_model_save_dir)
pretrained_tokenizer.save_pretrained(retrained_lm_model_save_dir)


checkpoint_path = os.path.join(checkpoints_dir, "final_checkpoint.pt")
torch.save({
    'iteration': iteration,
    'model_state_dict': model.state_dict(),
    'optimizer_state_dict': optimizer.state_dict(),
    'loss': loss
}, checkpoint_path)
print(f"Final checkpoint saved at {checkpoint_path}")

plt.figure(figsize=(10, 5))
plt.plot(losses, label="Training Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.title("Training Loss over Epochs")
plt.savefig('training_loss_plot.png')
plt.show()

print('Training completed', time.strftime('%X %x %Z'))



