#!/usr/bin/env python
# coding: utf-8

import torch
import os
import time
import pandas as pd
import h3
import matplotlib.pyplot as plt
from tqdm import tqdm
from datasets import load_dataset, Dataset
from transformers import AutoTokenizer, AutoModel, TrainingArguments, Trainer, DataCollatorWithPadding
from torch import nn
from torch.utils.data import DataLoader
from torch.nn.utils.rnn import pad_sequence

print("This is three task")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
batch_size=512
print("batch_size : ", batch_size)
state_to_do = 'PUNJAB'
address_data_path = f'/home/uddeshya.singh/DATA/PUNJAB_train/PUNJAB_with_grid_ids_train.csv'
fine_tuned_lm_trained_save_dir = '/home/uddeshya.singh/level-two_models/Fine-tuned-save'
fine_tuned_lm_trained_out_dir = '/home/uddeshya.singh/level-two_models/Fine-tuned-out'
model_dir = '/home/uddeshya.singh/Models/pan_india_train_threshold_save_dir/'

pretrained_tokenizer = AutoTokenizer.from_pretrained(model_dir)

print('Starting now ', time.strftime('%X %x %Z'))
df_train = pd.read_csv(address_data_path)

print('Completed loading ', time.strftime('%X %x %Z'))

def compute_grid_ids(row, res):
    return h3.geo_to_h3(row['lookup_lat'], row['lookup_lng'], res)

df_train['grid_id_res8'] = df_train.apply(compute_grid_ids, axis=1, res=8)
df_train['grid_id_res9'] = df_train.apply(compute_grid_ids, axis=1, res=9)
df_train['grid_id_res10'] = df_train.apply(compute_grid_ids, axis=1, res=10)

address_data_train = Dataset.from_pandas(df_train)
print(address_data_train)

def tokenize(batch):
    return pretrained_tokenizer(batch["cleaned_address"], padding=True, truncation=True, max_length=100)

def clean_dataset(batch):
    if pd.isnull(batch['cleaned_address']) or batch['cleaned_address'] == '':
        return False
    return True

print('starting now ', time.strftime('%X %x %Z'))
address_data_train = address_data_train.filter(clean_dataset)
print('completed now ', time.strftime('%X %x %Z'))

address_data_train = address_data_train.remove_columns(['addr_hash', 'lookup_lat', 'lookup_lng' , 'grid_id'])
address_data_train = address_data_train.class_encode_column("grid_id_res8")
address_data_train = address_data_train.class_encode_column("grid_id_res10")
address_data_train = address_data_train.class_encode_column("grid_id_res9")

train_dataset = address_data_train.map(tokenize, batched=True, batch_size=100000, num_proc=7)

train_dataset.set_format("torch", columns=["input_ids", "attention_mask", "grid_id_res8", "grid_id_res10", "grid_id_res9"])

def collate_fn(batch):
    input_ids = [item['input_ids'] for item in batch]
    attention_mask = [item['attention_mask'] for item in batch]
    labels_res8 = torch.tensor([item['grid_id_res8'] for item in batch])
    labels_res10 = torch.tensor([item['grid_id_res10'] for item in batch])
    labels_res9 = torch.tensor([item['grid_id_res9'] for item in batch])
    
    input_ids_padded = pad_sequence(input_ids, batch_first=True, padding_value=pretrained_tokenizer.pad_token_id)
    attention_mask_padded = pad_sequence(attention_mask, batch_first=True, padding_value=0)
    
    return {
        'input_ids': input_ids_padded,
        'attention_mask': attention_mask_padded,
        'labels_res8': labels_res8,
        'labels_res10': labels_res10,
        'labels_res9': labels_res9
    }

train_loader = DataLoader(train_dataset, batch_size=512, shuffle=True, collate_fn=collate_fn, pin_memory=True, num_workers=4)

num_labels_res8 = address_data_train.features["grid_id_res8"].num_classes
num_labels_res10 = address_data_train.features["grid_id_res10"].num_classes
num_labels_res9 = address_data_train.features["grid_id_res9"].num_classes

class MultiTaskModel(nn.Module):
    def __init__(self, model_name, num_labels_res8, num_labels_res10, num_labels_res9):
        super(MultiTaskModel, self).__init__()
        self.bert = AutoModel.from_pretrained(model_name)
        self.hidden_size = self.bert.config.hidden_size
        self.classifier_res8 = nn.Linear(self.hidden_size, num_labels_res8)
        self.classifier_res10 = nn.Linear(self.hidden_size, num_labels_res10)
        self.classifier_res9 = nn.Linear(self.hidden_size, num_labels_res9)
    
    def forward(self, input_ids, attention_mask=None, labels_res8=None, labels_res10=None, labels_res9=None):
        outputs = self.bert(input_ids, attention_mask=attention_mask)
        pooled_output = outputs[1]  
        logits_res8 = self.classifier_res8(pooled_output)
        logits_res10 = self.classifier_res10(pooled_output)
        logits_res9 = self.classifier_res9(pooled_output)

        loss = None
        if labels_res8 is not None and labels_res10 is not None and labels_res9 is not None:
            loss_fct = nn.CrossEntropyLoss()
            loss_res8 = loss_fct(logits_res8.view(-1, num_labels_res8), labels_res8.view(-1))
            loss_res10 = loss_fct(logits_res10.view(-1, num_labels_res10), labels_res10.view(-1))
            loss_res9 = loss_fct(logits_res9.view(-1, num_labels_res9), labels_res9.view(-1))
            loss = (3 * loss_res8) + (2 * loss_res9) + (1 * loss_res10)

        return loss, logits_res8, logits_res10, logits_res9

model = MultiTaskModel(model_dir, num_labels_res8, num_labels_res10, num_labels_res9)
model = nn.DataParallel(model)  
model.to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
num_epochs = 10

def train_model(model, train_loader, optimizer, num_epochs, save_dir, out_dir):
    loss_values = []
    save_interval = 5000
    iteration = 0

    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(out_dir, exist_ok=True)
    
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        for batch in tqdm(train_loader):
            input_ids = batch['input_ids'].to(device, non_blocking=True)
            attention_mask = batch['attention_mask'].to(device, non_blocking=True)
            labels_res8 = batch['labels_res8'].to(device, non_blocking=True)
            labels_res10 = batch['labels_res10'].to(device, non_blocking=True)
            labels_res9 = batch['labels_res9'].to(device, non_blocking=True)

            optimizer.zero_grad()
            loss, logits_res8, logits_res10, logits_res9 = model(input_ids, attention_mask, labels_res8, labels_res10, labels_res9)
            
            loss = loss.mean()
            
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            iteration += 1
            
            if iteration % save_interval == 0:
                model_save_path = f"{save_dir}/model_{epoch}_checkpoint_{iteration}.pt"
                optimizer_save_path = f"{out_dir}/optimizer_{epoch}_checkpoint_{iteration}.pt"
                torch.save(model.state_dict(), model_save_path)
                torch.save(optimizer.state_dict(), optimizer_save_path)
        
        avg_loss = total_loss / len(train_loader)
        loss_values.append(avg_loss)
        print(f"Epoch {epoch+1}/{num_epochs}, Loss: {avg_loss}")

    final_model_save_path = f"{save_dir}/MM_model.pt"
    torch.save(model.state_dict(), final_model_save_path)

    optimizer_save_path = f"{out_dir}/optimizer_MM.pt"
    torch.save(optimizer.state_dict(), optimizer_save_path)

    plt.figure()
    plt.plot(range(1, num_epochs + 1), loss_values, marker='o', label='Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss Over Epochs')
    plt.legend()
    plt.savefig(f"{save_dir}/training_loss.png")
    plt.show()

    return loss_values

print('starting now ', time.strftime('%X %x %Z'))
start_time = time.time()
train_model(model, train_loader, optimizer, num_epochs, fine_tuned_lm_trained_save_dir, fine_tuned_lm_trained_out_dir)
end_time = time.time()
print('completed now ', time.strftime('%X %x %Z'))
